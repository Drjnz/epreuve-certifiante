const container = document.getElementById("projects");

fetch("https://webcraft-api.vercel.app/data/projects.json")
  .then((response) => {
    if (!response.ok) {
      throw new Error(`Erreur HTTP : ${response.status}`);
    }
    return response.json();
  })
  .then((data) => {
    const projects = Array.isArray(data) ? data : data.projects || [];

    console.log(data);

    container.innerHTML = "";

    projects.forEach((project) => {
      const card = document.createElement("div");
      card.className = "card";

      const title = project.title;
      const client = project.client;
      const imageUrl = project.image;
      const technologies = project.technologies;
      const categories = project.categories || [];

      card.innerHTML = `
          ${imageUrl ? `<img src="${imageUrl}" alt="${title}" class="img-fluid" width="150">` : ""}
            <h2>${title}</h2>
            <p>${client}</p>
            <div class="mt-3">
              ${technologies.map((tech) => `<span class="badge bg-primary">${tech}</span>`).join("")}
            </div>
            <div class="mt-2">
              ${categories.map((category) => `<span class="badge bg-secondary">${category}</span>`).join("")}
            </div>
          `;
      container.appendChild(card);
    });
  })

  .catch((error) => {
    console.error(error);
    container.innerHTML = `<p class="error">Impossible de charger les projets : ${error.message}</p>`;
  });


//Affichage des formations, je reprends le même principe que pour les projets, mais avec l'élément "formations" et l'URL du fichier JSON correspondant.
const containerformation = document.getElementById("formations");

fetch("https://webcraft-api.vercel.app/data/courses.json")
  .then((response) => {
    if (!response.ok) {
      throw new Error(`Erreur HTTP : ${response.status}`);
    }
    return response.json();
  })
  .then((data) => {
    console.log(data);

    const courses = Array.isArray(data) ? data : data.courses || [];

    containerformation.innerHTML = "";

    courses.forEach((course) => {
      const card = document.createElement("div");
      card.className = "card";

      const title = course.title;
      const imageUrl = course.image;
      const level = course.level;
      const rating = course.rating;
      const categories = course.categories || [];

      //creation des cartes formations 
      card.innerHTML = `
        ${imageUrl ? `<img src="${imageUrl}" alt="${title}" class="img-fluid" width="150">` : ""}
        <h2>${title}</h2>
        <p>Note : ${rating}</p>
        <div class="mt-3">
        level : <span class="badge bg-primary">${level}</span>
        </div>
        <div class="mt-2">
          ${categories.map((category) => `<span class="badge bg-secondary">${category}</span>`).join("")}
        </div>
      `;
      containerformation.appendChild(card);
    });
  })
  //gestion des erreurs pour l'affichage des formations, similaire à celle des projets.
  .catch((error) => {
    console.error(error);
    containerformation.innerHTML = `<p class="error">Impossible de charger les formations : ${error.message}</p>`;
  });
