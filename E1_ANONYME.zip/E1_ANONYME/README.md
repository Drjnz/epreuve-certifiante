Utilisation de Bootstrap pour le style 
responsive du style (@media) généré par intelligence artificielle
Utilisation de Bootstrap dans les fichiers html
API exploité grace à "Fetch"
  
